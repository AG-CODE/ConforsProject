<html>
    <body>
        <h2>
            <?php
            echo 'Have a look at our Products!!';
            ?>
        </h2>
    </body>
</html>