<html>
    <body>
        <h2>
            <?php
            echo 'Welcome to Confors Plywood Manufacturers!!';
            ?>
        </h2>
    </body>
</html>