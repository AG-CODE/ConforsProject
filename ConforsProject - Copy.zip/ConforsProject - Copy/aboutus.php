<html>
    <body>
        <h2>
            <?php
            echo 'This is About us Section!!';
            ?>
        </h2>
    </body>
</html>